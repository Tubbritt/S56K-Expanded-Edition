# Compatibility

Firmware Updater 1.1 RC1 targets Intel/AMD 64-bit Windows 11 and the AKAI
S5000/S6000 with an IB-S56USB card and Microsoft's WinUSB driver. It accepts the
exact published original OS 2.14 and Expanded Edition V1, V1.1 and V1.2 images.

The bundled [START_HERE.html](../START_HERE.html) lists all four checksums and
explains setup, validation and the scope of the software checks. The prior
1.0 RC1 physical USB round-trip applies to that earlier executable and the
original/Expanded V1 images; it is not a hardware test of this new package.

[Current online compatibility record](https://github.com/Tubbritt/S56K-Expanded-Edition/blob/main/docs/COMPATIBILITY.md)
· [Package home](../README.md)
