# Installation

Open the bundled [START_HERE.html](../START_HERE.html) for this updater's complete
USB setup and installation instructions. Firmware Updater 1.1 RC1 supports the
four exact published images listed there, including Expanded Edition V1.2.

For floppy installation and the current online guide, see the
[S56K installation guide](https://github.com/Tubbritt/S56K-Expanded-Edition/blob/main/docs/INSTALLATION.md).

[Package home](../README.md) · [Disclaimer](../DISCLAIMER.md)
