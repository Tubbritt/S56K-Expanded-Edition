# S56K Firmware Updater 1.1 RC1

Standalone Windows 11 x64 USB updater for the AKAI S5000 and S6000 with an
IB-S56USB card and Microsoft's WinUSB driver.

Extract this entire ZIP, open **START_HERE.html**, then run
**S56K-Firmware-Updater.exe**. The firmware BIN is downloaded separately.

This version supports the exact published images for:

- Original Akai OS 2.14
- S56K Expanded Edition V1
- S56K Expanded Edition V1.1
- S56K Expanded Edition V1.2

The app validates the complete file before installation. Renaming an approved
BIN is fine; modified images and private test builds are rejected. The included
USB driver setup assistant can help select Microsoft's driver for the sampler.

[Current firmware and downloads](https://github.com/Tubbritt/S56K-Expanded-Edition)
· [Updater release notes](https://github.com/Tubbritt/S56K-Expanded-Edition/releases/tag/updater-v1.1-rc1)

Installation writes flash and stored settings. Save your work first, keep power
and USB connected throughout the update, and follow the setup guide. After
success, remove any firmware floppy and reboot. For V1.2, confirm the full
**EXPANDED EDITION V1.2** caption; the separate official OS field remains 2.14.

The earlier updater 1.0 RC1 completed a user-reported physical USB round-trip
between original OS 2.14 and Expanded V1. This 1.1 RC1 build adds support for the
newer images and has software validation; that earlier result does not establish
a physical USB installation test for this executable or V1.1/V1.2.

Free for personal and professional use under [LICENSE.md](LICENSE.md). Read
[DISCLAIMER.md](DISCLAIMER.md) and [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).
Keep these notices with unchanged copies you share. Firmware and application
development source remains private and is not included. The app is unsigned.

`SHA256SUMS.txt` identifies the exact files in this package.
